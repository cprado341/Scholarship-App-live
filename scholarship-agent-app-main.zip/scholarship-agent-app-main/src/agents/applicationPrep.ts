import type { ApplicationPlan, BrowserStep, DocumentRecord, Scholarship, Student } from "../types.ts";

export function prepareApplicationPlan(
  student: Student,
  scholarship: Scholarship,
  documents: DocumentRecord[]
): Omit<ApplicationPlan, "id" | "familyId" | "createdAt"> {
  const availableDocs = new Map(documents.filter((doc) => doc.studentId === student.id).map((doc) => [doc.type, doc]));
  const fieldMap: Record<string, string> = {
    student_name: student.profile.legalName || "",
    preferred_name: student.profile.preferredName || "",
    student_email: student.profile.email || "",
    confirmation_email: student.profile.email || "",
    graduation_year: String(student.profile.graduationYear),
    school_state: student.profile.schoolState,
    gpa: student.profile.gpa ? String(student.profile.gpa) : "",
    intended_majors: student.profile.intendedMajors.join(", "),
    activities_summary: student.profile.activities.join("; "),
    awards: student.profile.awards.join("; ")
  };
  const missingFields: string[] = [];
  const documentRequests: string[] = [];
  const requestedDocumentTypes = new Set<DocumentRecord["type"]>();

  if (!student.profile.email) {
    missingFields.push("Student email is required for scholarship submission confirmations.");
  }

  for (const requirement of scholarship.requirements) {
    if (requirement.kind === "need" && student.profile.financialNeed === "unknown") {
      missingFields.push("Financial need details require parent review.");
    }
    if (requirement.kind === "recommendation") {
      missingFields.push("Recommender name and email are required.");
      documentRequests.push("Recommendation letter or recommender request approval.");
    }
    if (requirement.kind === "attestation") {
      missingFields.push("Applicant attestation must be reviewed by the student before submission.");
    }
    if (requirement.kind === "document") {
      const requested = String(requirement.value ?? "other");
      requestedDocumentTypes.add(requested as DocumentRecord["type"]);
      const doc = availableDocs.get(requested as DocumentRecord["type"]);
      if (!doc || doc.status !== "available") {
        documentRequests.push(`${requirement.label} is ${doc?.status ?? "missing"}.`);
      }
    }
  }

  const browserSteps: BrowserStep[] = [
    { action: "navigate", url: scholarship.url, note: "Open scholarship application page." },
    ...Object.entries(fieldMap)
      .filter(([, value]) => value.trim().length > 0)
      .map(([selector, value]) => ({
        action: "fill" as const,
        selector: `[name="${selector}"]`,
        value,
        source: "student_profile"
      })),
    ...documents
      .filter((doc) => doc.studentId === student.id && doc.status === "available")
      .filter((doc) => requestedDocumentTypes.has(doc.type))
      .map((doc) => ({
        action: "upload" as const,
        selector: `[data-document="${doc.type}"]`,
        documentId: doc.id,
        note: `Stage ${doc.name}; requires approval before upload.`
      })),
    {
      action: "stop_for_review" as const,
      selector: `button[type="submit"], input[type="submit"]`,
      note: "Stop before any submit, signature, payment, recommendation request, or attestation action."
    }
  ];

  return {
    scholarshipId: scholarship.id,
    studentId: student.id,
    fieldMap,
    missingFields,
    documentRequests,
    browserSteps,
    status: missingFields.length > 0 || documentRequests.length > 0 ? "prepared" : "ready_for_review"
  };
}

export function assertNoSubmitSteps(steps: BrowserStep[]): void {
  const unsafe = steps.find((step) => {
    if (step.action === "stop_for_review" || step.action === "navigate") return false;
    return /button\[type="submit"\]|input\[type="submit"\]|click submit|final submit/i.test(JSON.stringify(step));
  });
  if (unsafe) {
    throw new Error(`Unsafe browser step attempted to submit: ${JSON.stringify(unsafe)}`);
  }
}
