# Deploying This Project

This repo is now safe to commit locally and includes a Vercel preview API under `api/[...path].js`.

The preview deployment works with seeded in-memory data so the login, dashboard, weekly run, approval queue, and safety gates can be demonstrated on Vercel.

It is not production-ready until the in-memory preview API is replaced with hosted storage.

## Why

The local app stores state in `data/app.sqlite` and serves through a long-running local Node server. The Vercel preview API stores state in warm function memory. Neither is durable production storage on Vercel. For production, move app data to hosted Postgres and document files to private object storage.

## Recommended Vercel Production Stack

- Vercel for the portal frontend and serverless API routes.
- Supabase or Neon Postgres for app data.
- Supabase Storage or Vercel Blob for private documents.
- Vercel Cron for weekly scholarship agent runs.
- A separate worker service for long browser automation if Playwright sessions become heavy.

## Environment Variables

Set these in Vercel before production deploy:

- `PORTAL_ADMIN_EMAIL`
- `PORTAL_ADMIN_PASSWORD`
- `CRON_SECRET`
- `PUBLIC_APP_URL`
- `INVITE_DELIVERY_MODE=manual` to create Settings invite links without sending email
- `RESEND_API_KEY` and `INVITE_EMAIL_FROM` for automatic Settings user invite emails
- `DATABASE_URL`
- `BLOB_READ_WRITE_TOKEN` if using Vercel Blob

## Deploy Flow

1. Push this repo to GitHub.
2. Create/import the project in Vercel.
3. Add the environment variables above.
4. Convert SQLite-backed repository code to hosted Postgres.
5. Replace `api/[...path].js` preview state with the hosted database adapter.
6. Validate login, weekly cron, approval gates, and no-submit safety checks.
7. Promote to production.

## Current Local Commands

Run locally:

```bash
./scripts/start-portal.command
```

Run tests:

```bash
/Users/carlosp/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node --test --disable-warning=ExperimentalWarning tests/*.test.ts
```
