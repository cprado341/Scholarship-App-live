import { randomUUID } from "node:crypto";
import { createAssistedBrowserSession } from "../src/agents/browser.ts";
import { discoverScholarshipsFromPublicSources } from "../src/agents/discovery.ts";
import { dedupeScholarships, scoreScholarship } from "../src/agents/eligibility.ts";
import { draftEssayFromInterview } from "../src/agents/essay.ts";
import { prepareApplicationPlan } from "../src/agents/applicationPrep.ts";
import { riskForRequirements } from "../src/agents/policy.ts";
import { sampleStudentProfile } from "../src/sampleData.ts";
import type {
  AgentRun,
  ApplicationPlan,
  Approval,
  AuditEvent,
  DashboardData,
  DocumentRecord,
  EssayDraft,
  Family,
  PortalUser,
  Scholarship,
  Student
} from "../src/types.ts";

interface VercelRequest {
  method?: string;
  url?: string;
  headers: Record<string, string | string[] | undefined>;
  body?: any;
}

interface VercelResponse {
  status(code: number): VercelResponse;
  setHeader(name: string, value: string | string[]): void;
  json(payload: unknown): void;
  send(payload: string): void;
  end(payload?: string): void;
}

interface PortalState {
  family: Family;
  user: PortalUser;
  students: Student[];
  scholarships: Scholarship[];
  documents: DocumentRecord[];
  essayDrafts: EssayDraft[];
  applicationPlans: ApplicationPlan[];
  approvals: Approval[];
  auditEvents: AuditEvent[];
  agentRuns: AgentRun[];
}

const SESSION_COOKIE = "scholarship_session";
const SESSION_VALUE = "vercel-preview-session";
const FAMILY_ID = "family_vercel_preview";
const USER_ID = "user_vercel_preview";

declare global {
  // eslint-disable-next-line no-var
  var __scholarshipPortalState: PortalState | undefined;
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const url = new URL(req.url ?? "/api", "https://scholarship-agent.vercel.app");
  const pathname = url.pathname;
  const method = req.method ?? "GET";

  try {
    if (pathname === "/api/auth/login" && method === "POST") {
      const body = normalizeBody(req.body);
      const email = String(body.email ?? "");
      const password = String(body.password ?? "");
      if (!isValidLogin(email, password)) {
        return sendJson(res, 401, { error: "Email or password was not recognized." });
      }
      setSessionCookie(res);
      return sendJson(res, 200, { user: publicUser(state().user) });
    }

    if (pathname === "/api/auth/logout" && method === "POST") {
      clearSessionCookie(res);
      return sendJson(res, 200, { ok: true });
    }

    if (pathname === "/api/cron/weekly" && method === "POST") {
      if (!isAuthorizedCron(req)) return sendJson(res, 401, { error: "Missing or invalid cron secret." });
      const run = runWeeklyPipelinePreview(state());
      return sendJson(res, 200, { run });
    }

    if (pathname === "/api/public/invite-request" && method === "POST") {
      const result = createInviteRequestMailtoPreview(normalizeBody(req.body));
      if ("error" in result) return sendJson(res, 400, { error: result.error });
      return sendJson(res, 200, result);
    }

    const current = requireSession(req, res);
    if (!current) return;

    if (pathname === "/api/me" && method === "GET") {
      const data = state();
      return sendJson(res, 200, { user: publicUser(data.user), family: data.family, runtime: "vercel-preview" });
    }

    if (pathname === "/api/events" && method === "GET") {
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache, no-transform");
      res.send(`event: connected\ndata: ${JSON.stringify({ type: "connected", message: "Vercel preview API connected." })}\n\n`);
      return;
    }

    if (pathname === "/api/dashboard" && method === "GET") {
      return sendJson(res, 200, dashboard(state()));
    }

    if (pathname === "/api/runs/weekly" && method === "POST") {
      const data = state();
      const run = runWeeklyPipelinePreview(data);
      return sendJson(res, 200, { run, dashboard: dashboard(data) });
    }

    const approvalMatch = pathname.match(/^\/api\/approvals\/([^/]+)\/decision$/);
    if (approvalMatch && method === "POST") {
      const data = state();
      const body = normalizeBody(req.body);
      if (body.status !== "approved" && body.status !== "rejected") {
        return sendJson(res, 400, { error: "status must be approved or rejected" });
      }
      const approval = data.approvals.find((item) => item.id === approvalMatch[1]);
      if (!approval) return sendJson(res, 404, { error: "Approval not found" });
      approval.status = body.status;
      approval.decidedAt = new Date().toISOString();
      approval.decisionNote = String(body.note ?? "Decision recorded in Vercel preview.");
      audit(data, "parent", `approval_${body.status}`, approval.targetType, approval.targetId, {
        actionType: approval.actionType
      });
      return sendJson(res, 200, { approval, dashboard: dashboard(data) });
    }

    if (pathname === "/api/browser-sessions" && method === "POST") {
      const data = state();
      const body = normalizeBody(req.body);
      const plan = data.applicationPlans.find((item) => item.id === body.applicationPlanId);
      if (!plan) return sendJson(res, 404, { error: "Application plan not found" });
      const session = createAssistedBrowserSession(plan);
      audit(data, "agent", "browser_session_prepared", "application_plan", plan.id, {
        steps: session.steps.length,
        blockedActions: session.blockedActions
      });
      return sendJson(res, 200, session);
    }

    if (pathname === "/api/export" && method === "GET") {
      return sendJson(res, 200, dashboard(state()));
    }

    return sendJson(res, 404, { error: "Not found" });
  } catch (error) {
    return sendJson(res, 500, { error: error instanceof Error ? error.message : "Unknown error" });
  }
}

function state(): PortalState {
  if (globalThis.__scholarshipPortalState) return globalThis.__scholarshipPortalState;

  const now = new Date().toISOString();
  const profile = sampleStudentProfile();
  const student: Student = {
    id: randomUUID(),
    familyId: FAMILY_ID,
    name: profile.preferredName,
    graduationYear: profile.graduationYear,
    schoolState: profile.schoolState,
    profile,
    createdAt: now
  };

  globalThis.__scholarshipPortalState = {
    family: { id: FAMILY_ID, name: "My Family", createdAt: now },
    user: {
      id: USER_ID,
      familyId: FAMILY_ID,
      email: process.env.PORTAL_ADMIN_EMAIL ?? "parent@example.com",
      displayName: "Parent",
      role: "parent",
      createdAt: now
    },
    students: [student],
    scholarships: [],
    documents: [
      {
        id: randomUUID(),
        familyId: FAMILY_ID,
        studentId: student.id,
        type: "resume",
        name: "Student activities resume",
        path: "vercel-preview/resume-placeholder.pdf",
        status: "available",
        uploadedAt: now
      },
      {
        id: randomUUID(),
        familyId: FAMILY_ID,
        studentId: student.id,
        type: "transcript",
        name: "Unofficial transcript",
        path: "vercel-preview/transcript-placeholder.pdf",
        status: "needs_update",
        uploadedAt: now
      }
    ],
    essayDrafts: [],
    applicationPlans: [],
    approvals: [],
    auditEvents: [],
    agentRuns: []
  };
  audit(globalThis.__scholarshipPortalState, "system", "vercel_preview_seeded", "family", FAMILY_ID, {
    note: "Preview state is in-memory. Configure Postgres before production use."
  });
  return globalThis.__scholarshipPortalState;
}

function runWeeklyPipelinePreview(data: PortalState): AgentRun {
  const started = new Date().toISOString();
  const run: AgentRun = {
    id: randomUUID(),
    familyId: FAMILY_ID,
    runType: "weekly_pipeline",
    status: "running",
    summary: "Finding scholarships and preparing the review queue.",
    createdAt: started,
    output: {}
  };
  data.agentRuns.unshift(run);
  const student = data.students[0];
  const discovered = dedupeScholarships(discoverScholarshipsFromPublicSources());

  for (const item of discovered) {
    let scholarship = data.scholarships.find((candidate) => candidate.url === item.url);
    const score = scoreScholarship(student, {
      id: scholarship?.id ?? "preview",
      familyId: FAMILY_ID,
      ...item,
      status: scholarship?.status ?? "new",
      fitScore: scholarship?.fitScore ?? 0,
      effort: scholarship?.effort ?? "medium",
      createdAt: scholarship?.createdAt ?? started
    } as Scholarship);

    if (!scholarship) {
      scholarship = {
        id: randomUUID(),
        familyId: FAMILY_ID,
        title: item.title,
        provider: item.provider,
        url: item.url,
        award: item.award,
        deadline: item.deadline,
        status: "matched",
        fitScore: score.fitScore,
        effort: score.effort,
        requirements: item.requirements,
        risks: score.risks,
        tags: item.tags,
        sourceQuote: item.sourceQuote,
        createdAt: started
      };
      data.scholarships.push(scholarship);
    } else {
      scholarship.fitScore = score.fitScore;
      scholarship.effort = score.effort;
      scholarship.status = score.fitScore >= 60 ? "matched" : "new";
      scholarship.risks = score.risks;
    }
    audit(data, "agent", "scholarship_scored", "scholarship", scholarship.id, {
      fitScore: score.fitScore,
      effort: score.effort
    });
  }

  const ranked = data.scholarships
    .filter((scholarship) => scholarship.fitScore >= 60)
    .sort((a, b) => b.fitScore - a.fitScore || a.deadline.localeCompare(b.deadline))
    .slice(0, 3);

  for (const scholarship of ranked) {
    scholarship.status = "ready_for_review";
    const essay = draftEssayFromInterview(student, scholarship);
    upsertEssay(data, {
      id: randomUUID(),
      familyId: FAMILY_ID,
      updatedAt: new Date().toISOString(),
      ...essay
    });
    const plan = upsertPlan(data, {
      id: randomUUID(),
      familyId: FAMILY_ID,
      createdAt: new Date().toISOString(),
      ...prepareApplicationPlan(student, scholarship, data.documents)
    });
    createApprovalIfMissing(data, {
      actionType: "portal_submit",
      targetType: "application_plan",
      targetId: plan.id,
      summary: `Review ${scholarship.title} for ${student.profile.preferredName}. The app will not submit without this approval.`,
      riskLevel: riskForRequirements(scholarship.requirements)
    });
    if (plan.browserSteps.some((step) => step.action === "upload")) {
      createApprovalIfMissing(data, {
        actionType: "file_upload",
        targetType: "application_plan",
        targetId: plan.id,
        summary: `Approve document staging/upload for ${scholarship.title}.`,
        riskLevel: "medium"
      });
    }
  }

  run.status = "completed";
  run.summary = `Prepared ${ranked.length} scholarship applications for review.`;
  run.completedAt = new Date().toISOString();
  run.output = { discovered: discovered.length, preparedForReview: ranked.length };
  return run;
}

function dashboard(data: PortalState): DashboardData {
  return {
    family: data.family,
    user: publicUser(data.user),
    students: data.students,
    scholarships: [...data.scholarships].sort((a, b) => b.fitScore - a.fitScore || a.deadline.localeCompare(b.deadline)),
    documents: data.documents,
    essayDrafts: data.essayDrafts,
    applicationPlans: data.applicationPlans,
    approvals: data.approvals,
    auditEvents: data.auditEvents.slice(0, 80),
    agentRuns: data.agentRuns.slice(0, 25)
  };
}

function upsertEssay(data: PortalState, draft: EssayDraft) {
  const index = data.essayDrafts.findIndex((item) => item.studentId === draft.studentId && item.scholarshipId === draft.scholarshipId);
  if (index >= 0) data.essayDrafts[index] = { ...data.essayDrafts[index], ...draft, id: data.essayDrafts[index].id };
  else data.essayDrafts.unshift(draft);
}

function upsertPlan(data: PortalState, plan: ApplicationPlan): ApplicationPlan {
  const index = data.applicationPlans.findIndex((item) => item.studentId === plan.studentId && item.scholarshipId === plan.scholarshipId);
  if (index >= 0) {
    data.applicationPlans[index] = { ...data.applicationPlans[index], ...plan, id: data.applicationPlans[index].id };
    return data.applicationPlans[index];
  }
  data.applicationPlans.unshift(plan);
  return plan;
}

function createApprovalIfMissing(
  data: PortalState,
  input: Omit<Approval, "id" | "familyId" | "status" | "requestedAt">
) {
  const existing = data.approvals.find(
    (approval) =>
      approval.actionType === input.actionType &&
      approval.targetType === input.targetType &&
      approval.targetId === input.targetId &&
      approval.status === "pending"
  );
  if (existing) return;
  data.approvals.unshift({
    id: randomUUID(),
    familyId: FAMILY_ID,
    status: "pending",
    requestedAt: new Date().toISOString(),
    ...input
  });
}

function audit(
  data: PortalState,
  actor: AuditEvent["actor"],
  eventType: string,
  targetType: string,
  targetId: string,
  detail: Record<string, unknown>
) {
  data.auditEvents.unshift({
    id: randomUUID(),
    familyId: FAMILY_ID,
    actor,
    eventType,
    targetType,
    targetId,
    detail,
    createdAt: new Date().toISOString()
  });
}

function isValidLogin(email: string, password: string) {
  const expectedEmail = process.env.PORTAL_ADMIN_EMAIL ?? "parent@example.com";
  const expectedPassword = process.env.PORTAL_ADMIN_PASSWORD ?? "change-me-now";
  return email.toLowerCase() === expectedEmail.toLowerCase() && password === expectedPassword;
}

function requireSession(req: VercelRequest, res: VercelResponse): true | undefined {
  if (cookie(req).includes(`${SESSION_COOKIE}=${SESSION_VALUE}`)) return true;
  sendJson(res, 401, { error: "Please sign in first.", loginUrl: "/login?next=/portal.html" });
  return undefined;
}

function createInviteRequestMailtoPreview(input: any): { mailtoHref: string } | { error: string } {
  const name = cleanText(input?.name).slice(0, 120);
  const email = cleanText(input?.email).toLowerCase().slice(0, 160);
  const studentGrade = cleanText(input?.studentGrade).slice(0, 40);
  const note = cleanText(input?.note).slice(0, 500);
  if (!name) return { error: "Parent name is required." };
  if (!isValidEmail(email)) return { error: "A valid email address is required." };
  const to = inviteRequestEmailPreview();
  const subject = `Scholarship Agent invite request from ${name}`;
  const body = [
    "New Scholarship Agent invite request",
    "",
    `Parent name: ${name}`,
    `Email: ${email}`,
    `Student grade: ${studentGrade || "Not provided"}`,
    "",
    "Note:",
    note || "Not provided"
  ].join("\n");
  return { mailtoHref: `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}` };
}

function inviteRequestEmailPreview(): string {
  return cleanText(process.env.PUBLIC_INVITE_REQUEST_EMAIL)
    || cleanText(process.env.PORTAL_ADMIN_EMAIL)
    || "parent@example.com";
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isAuthorizedCron(req: VercelRequest) {
  const secret = process.env.CRON_SECRET ?? "local-cron-secret";
  const authorization = header(req, "authorization");
  return authorization === `Bearer ${secret}` || header(req, "x-cron-secret") === secret;
}

function publicUser(user: PortalUser) {
  return {
    id: user.id,
    email: user.email,
    displayName: user.displayName,
    role: user.role
  };
}

function normalizeBody(body: any) {
  if (!body) return {};
  if (typeof body === "string") {
    try {
      return JSON.parse(body);
    } catch {
      return {};
    }
  }
  return body;
}

function cleanText(value: any): string {
  return String(value ?? "").trim();
}

function setSessionCookie(res: VercelResponse) {
  res.setHeader("Set-Cookie", `${SESSION_COOKIE}=${SESSION_VALUE}; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=1209600`);
}

function clearSessionCookie(res: VercelResponse) {
  res.setHeader("Set-Cookie", `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=0`);
}

function cookie(req: VercelRequest) {
  return header(req, "cookie");
}

function header(req: VercelRequest, name: string) {
  const value = req.headers[name] ?? req.headers[name.toLowerCase()];
  return Array.isArray(value) ? value.join(",") : value ?? "";
}

function sendJson(res: VercelResponse, status: number, payload: unknown) {
  res.status(status).json(payload);
}
